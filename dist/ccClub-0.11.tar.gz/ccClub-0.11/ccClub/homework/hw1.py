def func():
    print("a")
