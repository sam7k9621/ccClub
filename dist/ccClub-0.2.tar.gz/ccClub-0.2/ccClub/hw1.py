def ans():
    print("hello world")
