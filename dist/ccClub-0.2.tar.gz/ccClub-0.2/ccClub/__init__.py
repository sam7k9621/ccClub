from ccClub.hw1 import ans
