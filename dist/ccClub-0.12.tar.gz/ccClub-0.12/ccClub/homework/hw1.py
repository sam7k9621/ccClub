def ans():
    print("a")
