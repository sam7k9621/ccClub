from ccClub.homework.hw1 import ans
print("A")
